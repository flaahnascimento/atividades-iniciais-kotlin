package atividade2

fun main() {
    //calcule o mod da uma divisao
    val a = 25
    val b = 6

    val resultado = a % b // Calculando o resto da divisão de a por b

    println("o resto da divisao é $resultado")
}