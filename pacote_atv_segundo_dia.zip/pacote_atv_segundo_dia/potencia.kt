package atividade2

fun main(){
        val base = 2.0
        val expoente = 3.0
        val potencia = Math.pow(base,expoente)//2^3=8.0
        println(potencia)
}