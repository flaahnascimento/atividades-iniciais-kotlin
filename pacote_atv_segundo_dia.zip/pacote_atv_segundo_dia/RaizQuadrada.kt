package atividade2

fun main(){
    val numero = 25.0
    val raizQuadrada = Math.sqrt(numero)// raiz 25 = 5.0
    println(raizQuadrada) //exibe 5.0
}