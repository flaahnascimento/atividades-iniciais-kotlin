package atividade2

fun main() {
    val a = 3
    val b = 5
    val resultado = 2 * a * 3 * b // 3 * 5
    println(resultado)
}