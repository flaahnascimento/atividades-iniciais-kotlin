package atividade2

fun main() {
    var salario = 1500
    val porcentagem = 0.15
    //var é mutavel enquanto val é imutavel
}