package atividade2

fun main() {
    val a = 17
    val b = 5
    val c = 8
    val resultado = a  + b + c // soma de tres variaveis
    println(resultado)
}