package atividade2

fun main() {
    val distancia = 25000 // Distância em metros 25000
    val velocidade = 90 // 90km/h

    // Convertendo a distância de metros para quilômetros - de 25000 para 25km
    val distanciaEmKm = distancia / 1000.0

    // Calculando o tempo da viagem em horas - quilometros dividido por velocidade
    val resultado = distanciaEmKm / velocidade

    println("o tempo da viagem de carro foi $resultado")
}

