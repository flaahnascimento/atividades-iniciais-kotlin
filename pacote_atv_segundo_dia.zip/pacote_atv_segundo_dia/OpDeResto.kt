package atividade2

fun main() {
    val a = 17
    val b = 5
    val resultado = a % b // 17 dividido por 5 dá 3 de quociente e 2 de resto
    println("O resto da divisão de $a por $b é $resultado")
}