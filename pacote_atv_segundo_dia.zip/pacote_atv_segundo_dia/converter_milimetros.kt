package atividade2

fun main() {
    var metros = 1000
    var resultado = metros * 1000 // convertendo em milimetros
        println("$metros metros é igual a $resultado milímetros")
}