package atividade2

fun main(){
    val letra: Char = 'a' //char
    val saudacao = "ola"
    val nome = "Kotlin" //string
    val mensagem = saudacao + "" + nome //ou template para contatenar $saudacao + " " + $nome
}
