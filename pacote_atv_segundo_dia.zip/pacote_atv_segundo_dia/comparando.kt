package atividade2

fun main(){
    val a = "kotlin"
    val b = "kotlin"
    val c = a
    println(a === b)
    println(a === c)
}