package atividade2

fun main() {
    val salario = 1500
    val porcentagem = 0.15
    val resultado = salario * porcentagem //calculo dos 15% do salario
    println("15% do salário de R$$salario é R$$resultado")
}