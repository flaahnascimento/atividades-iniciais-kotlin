package todas_juntas

fun main() {
    val num1 = 52
    val num2 = 106

    // Soma
    val resultadoSoma = num1 + num2
    println("O resultado da soma é $resultadoSoma")

    // Subtração
    val resultadoSubtracao = num1 - num2
    println("O resultado da subtração é $resultadoSubtracao")

    // Verificando se os números são iguais
    val verificandoIgualdade = num1 == num2
    println("Os valores de num1 e num2 são iguais? resposta = $verificandoIgualdade")

    // Verificando se os números são diferentes
    val verificandoDiferenca = num1 != num2
    println("Os valores de num1 e num2 são diferentes? resposta = $verificandoDiferenca")

    // Verificando se num1 é menor ou igual a 100
    val verificandoMenorOuIgual = num1 <= 100
    println("O valor de num1 é menor ou igual a 100? resposta = $verificandoMenorOuIgual")

    // Verificando se ambos os valores são menores ou iguais a 100
    val verificandoValoresMenoresOuIguais = num1 <= 100 && num2 <= 100
    println("Os valores de num1 e num2 são menores ou iguais a 100? resposta = $verificandoValoresMenoresOuIguais")

    // Verificando se ambos os valores são maiores ou iguais a 100
    val verificandoValoresMaioresOuIguais = num1 >= 100 && num2 >= 100
    println("Os valores de num1 e num2 são maiores ou iguais a 100? resposta = $verificandoValoresMaioresOuIguais")
}
