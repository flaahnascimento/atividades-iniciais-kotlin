package pacote

fun main(args: Array<String>) { /* funçao main é o ponto de partida, todos codigos
    devem estar dentro dela, tipo o int main() do c++ */
    println("Hello word!")
    print("Meu primeiro nome: Flavia")
}