package pacote

fun main(args: Array<String>){
    val num1 = 10
    val num2 = 5
    val resultado = num1 + num2
    println(resultado)
}



