package pacote

fun main(args: Array<String>){
    val num1 = 20
    val num2 = 7
    val mult = num1 * num2
    println(mult)
}