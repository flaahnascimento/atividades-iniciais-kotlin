package pacote

fun main(args: Array<String>){
    val base = 3
    val altura = 7
    val resultado = base * altura
    println(resultado)
}