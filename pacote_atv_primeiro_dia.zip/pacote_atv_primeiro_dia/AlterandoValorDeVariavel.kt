package pacote

fun main(args: Array<String>){
    var idade = 22 //inicializa no 22
    idade = 26
    println(idade)
}